<?php

namespace Illuminate\Database\Events;

class TransactionCommitting extends ConnectionEvent
{
    //
}
